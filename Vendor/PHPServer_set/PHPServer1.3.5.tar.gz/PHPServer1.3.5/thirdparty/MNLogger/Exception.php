<?php
namespace thirdparty\MNLogger;

class Exception extends \Exception{

}
