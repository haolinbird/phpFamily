<?php

namespace Anodoc\Collection;

class NotATagException extends \Anodoc\Exception {}