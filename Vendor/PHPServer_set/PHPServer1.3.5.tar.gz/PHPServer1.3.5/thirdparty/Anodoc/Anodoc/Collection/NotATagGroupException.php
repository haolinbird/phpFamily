<?php

namespace Anodoc\Collection;

class NotATagGroupException extends \Anodoc\Exception {}