<?php

namespace Anodoc;

class Exception extends \Exception {}