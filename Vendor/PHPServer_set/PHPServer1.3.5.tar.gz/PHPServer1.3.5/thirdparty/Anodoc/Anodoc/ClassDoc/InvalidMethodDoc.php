<?php

namespace Anodoc\ClassDoc;

use Anodoc\Exception;

class InvalidMethodDoc extends Exception {}