<?php

namespace Anodoc\ClassDoc;

use Anodoc\Exception;

class InvalidAttributeDoc extends Exception {}