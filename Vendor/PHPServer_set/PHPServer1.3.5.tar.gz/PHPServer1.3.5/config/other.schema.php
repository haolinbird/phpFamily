<?php
// 配额
$quota_config = "#{RPC.QuotaConfig}";
// 手机告警
$rpc_alarm_config = "#{RPC.AlarmPhone}";